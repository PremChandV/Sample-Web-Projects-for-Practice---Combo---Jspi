function addition()
{
	var num1 = 15
	var num2 = 35

	var rslt = num1 + num2

	document.write("The Sum of "+"<strong>" +num1+ "</strong>"+" + "+"<strong>" +num2+ "</strong>"+" = " + "<strong>" +rslt+ "</strong><br></br>")
}

function subtraction()
{
	var num1 = 15
	var num2 = 35

	var rslt = num1 - num2

	document.write("The Subtraction of "+"<strong>"+num1+"</strong>"+" and "+"<strong>"+num2+"</strong>"+" is " + "<strong>"+rslt+"</strong><br></br>")
}

function multiplication()
{
	var num1 = 15
	var num2 = 35

	var rslt = num1 * num2

	document.write("The Multiplication of "+"<strong>"+num1+"</strong>"+" * "+"<strong>"+num2+"</strong>"+" = " + "<strong>"+rslt+"</strong><br></br>")
}

function division()
{
	var num1 = 15
	var num2 = 35

	var rslt = num1 / num2

	document.write("The Division of "+"<strong>"+num1+"</strong>"+" and "+"<strong>"+num2+"</strong>"+" is " + "<strong>"+rslt+"</strong><br></br>")
}



	addition()
	subtraction()
	multiplication()
	division()