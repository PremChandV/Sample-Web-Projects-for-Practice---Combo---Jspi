function checkPhoneNum()
{
	var phone = document.getElementById("pNum").value
	var phoneLen = phone.length

	var regExp1 = /[0-9]/
	var regExp2 = /[^6-9]/
	var regExp4 = /[^0-9]/

	if (phoneLen == 0)
	{	
		var msg = ""
		document.getElementById("phn-err").innerHTML = msg
	}

	else if (phone.match(regExp1) && phoneLen == 13)
	{
		var msg = "Valid"
		document.getElementById("phn-err").innerHTML = msg
	}

	else if (phone.match(regExp4) || phone.match(regExp2))
	{
		var msg = "Invalid"
		document.getElementById("phn-err").innerHTML = msg
	}
}

function checkPassword()
{
	var pass = document.getElementById("psw").value
	var passLen = pass.length

	var regExp = /(?=.*[A-Z])(?=.*[a-z])(?=.*[!@#$%&*_])(?=.*[0-9])/

	if (pass.match(regExp))
	{
		var msg = "Valid"
		document.getElementById("psw-err").innerHTML = msg
	}

	else 
	{
		var msg = "Invalid"
		document.getElementById("psw-err").innerHTML = msg
	}
}

function countryCode()
{
	document.getElementById("pNum").setAttribute("value", "+91")
}







	



