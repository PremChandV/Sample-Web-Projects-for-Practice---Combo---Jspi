function showPassword()
{
	document.getElementById("psw").removeAttribute("type")
}

function hidePassword()
{
	document.getElementById("psw").setAttribute("type", "password")
}

function showHidePassword()
{
	var associatedValue = document.getElementById("psw").getAttribute("type")

	if (associatedValue == "password")
	{
		document.getElementById("psw").removeAttribute("type")
		document.getElementById("eye").setAttribute("class", "fa fa-eye")
	}

	else
	{
		document.getElementById("psw").setAttribute("type", "password")
		document.getElementById("eye").setAttribute("class", "fa fa-eye-slash")
	}
}


function mobileNumber()
{
	var uMob = document.getElementById("mNum").value

	var uMobLen = uMob.length

	if (uMobLen == 10)
	{
		document.getElementById("smbl").setAttribute("class", "fa fa-check")
		document.getElementById("smbl").style.color = "green"
		document.getElementById("mNum").style.borderColor = "green"
	}

	else if (uMobLen == 0)
	{
		document.getElementById("smbl").setAttribute("class", "")
		document.getElementById("smbl").style.color = "black"
		document.getElementById("mNum").style.borderColor = "black"
	}

	else
	{
		document.getElementById("smbl").setAttribute("class", "fa fa-times")
		document.getElementById("smbl").style.color = "red"
		document.getElementById("mNum").style.borderColor = "red"
	}
}
