function allOperations()
{
	var number1 = document.getElementById("num1").value
	var number2 = document.getElementById("num2").value

	var radio1 = document.getElementById("add").checked
	var radio2 = document.getElementById("sub").checked
	var radio3 = document.getElementById("multi").checked
	var radio4 = document.getElementById("divi").checked

	if (radio1 ==  false && radio2 == false && radio3 == false && radio4 = false)
	{
		var msg = "Please Select Operation!"
		document.getElementById("err").innerHTML = msg
	}
	else if (radio1 == true)
	{
		var sum = parseInt(number1) + parseInt(number2)
		document.getElementById("rslt").innerHTML = sum

		var msg = ""
		document.getElementById("err").innerHTML = msg
	}

	else if (radio2 == true)
	{
		var diff = number1 - number2
		document.getElementById("rslt").innerHTML = diff

		var msg = ""
		document.getElementById("err").innerHTML = msg
	}

	else if (radio3 == true)
	{
		var prod = number1 * number2
		document.getElementById("rslt").innerHTML = prod

		var msg = ""
		document.getElementById("err").innerHTML = msg
	}

	else if (radio4 == true)
	{
		var quo = number1 / number2
		document.getElementById("rslt").innerHTML = quo

		var msg = ""
		document.getElementById("err").innerHTML = msg
	}
}