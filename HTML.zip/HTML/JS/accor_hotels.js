function checkEmailId()
{
	var uMail = document.getElementById("mail-ip").value
	var uMailLen = uMail.length

	if (uMailLen != 0)
	{
		var msg = ""
		document.getElementById("mail-err").innerHTML = msg
		document.getElementById("smbl_1").setAttribute("class", "fa fa-check fa-lg")
		document.getElementById("smbl_1").style.color = "green"
		document.getElementById("mail-ip").style.borderColor = "green"
		document.getElementById("label-1").style.color = "black"
		document.getElementById("example").style.color = "black"
	}

	else
	{
		var msg = "Please Enter Your Email Id"
		document.getElementById("mail-err").innerHTML = msg
		document.getElementById("smbl_1").setAttribute("class", "fa fa-exclamation-circle fa-lg")
		document.getElementById("mail-ip").style.borderColor = "red"
		document.getElementById("smbl_1").style.color = "red"
		document.getElementById("label-1").style.color = "red"
		document.getElementById("example").style.color = "red"
	}
}

function checkPassword()
{
	var uPass = document.getElementById("psw").value
	var uPassLen = uPass.length

	if(uPassLen >= 8)
	{
		var msg = ""
		document.getElementById("psw-err").innerHTML = msg
		document.getElementById("smbl_2").setAttribute("class", "fa fa-check fa-lg")
		document.getElementById("smbl_2").style.color = "green"
		document.getElementById("smbl_3").style.borderColor = "green"
		document.getElementById("psw").style.borderColor = "green"
		document.getElementById("label-2").style.color = "black"
	}
	else
	{
		var msg = "Please Enter Your Password"
		document.getElementById("psw-err").innerHTML = msg
		document.getElementById("smbl_2").setAttribute("class", "fa fa-exclamation-circle fa-lg")
		document.getElementById("psw").style.borderColor = "red"
		document.getElementById("smbl_3").style.borderColor = "red"
		document.getElementById("smbl_2").style.color = "red"
		document.getElementById("label-2").style.color = "red"
	}
}

function showHidePassword()
{
	var associatedValue = document.getElementById("psw").getAttribute("type")

	if (associatedValue == "password")
	{
		document.getElementById("psw").removeAttribute("type")
		document.getElementById("smbl_3").setAttribute("class", "fa fa-eye-slash fa-lg")
	}

	else if (associatedValue == "")
	{
		document.getElementById("psw").setAttribute("type", "password")
		document.getElementById("smbl_3").setAttribute("class", "fa-exclamation-circle")
	}

	else
	{
		document.getElementById("psw").setAttribute("type", "password")
		document.getElementById("smbl_3").setAttribute("class", "fa fa-eye fa-lg")
	}
}