var num = 20
var price = 25.75
var gen = 'M'
var str = "PKS"
var status = true

document.write(num + "<br></br>")
document.write(price + "<br></br>")
document.write(gen + "<br></br>")
document.write(str + "<br></br>")
document.write(status + "<br></br>")


var name = "Prem"
var address = "Hyd"
var height = 5.6
var age = "25"
var gender = 'M'

document.write("My Name is " + "<strong>"+name+"</strong><br></br>")
document.write("My Address is "+"<strong>"+address+"</strong><br></br>")
document.write("My Height is "+"<strong>"+height+"</strong><br></br>")
document.write("my Age is "+"<strong>"+age+"</strong><br></br>")
document.write("My Gender is "+"<strong>"+gender+"</strong><br></br>")