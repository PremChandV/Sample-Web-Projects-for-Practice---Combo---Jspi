function generateOTP()
{
	document.write("OTP Generated Successfully!")
}

function verifyOTP()
{
	document.write("OTP Verified Successfully!")
}